# Cancer Medicine revision analysis code

This curated release keeps only three code groups. `CODE_MAP.csv` links each script to its manuscript figure/table, reviewer comment, source provenance, and run status.

## Contents

1. `01_Main_Analyses/` — the final analysis workflows used for the manuscript, plus four small shared configuration files.
2. `02_Reviewer_Analyses/` — additional analyses requested during peer review, with the reviewer comment identified in each script and in `CODE_MAP.csv`.
3. `03_Final_Figure_Code/` — available drawing and supplementary assembly sources for selected final panels.

There are 37 indexed files: 33 analysis/plot scripts and 4 configuration dependencies. A script used by both an analysis and a figure is included once, with both references recorded in the map. No patient-level data, RDS/RData objects, source figures, manuscript drafts, or results tables are included.

## Reproducibility scope

This is a curated source-code release, not a self-contained one-click pipeline. The input data and selected legacy serialized objects are held separately because they contain patient-level information. Each workflow needs its documented inputs and R/Python packages. Scientific analyses were not rerun during this curation.

A syntax-only check is provided in `VALIDATION.md`. Passing syntax checks does not establish that a scientific result has been regenerated.

## Figure source notes

The scripts in `03_Final_Figure_Code` cover Figure 1h, Figure 3g, Figure 5a, Figure 5g, the external MGS panel, and selected supplementary assembly. The remaining main-figure panels are based on the previously prepared figures and were manually assembled or adjusted. Their final visual layout is not represented by a reproducible panel-generation script in this curated folder. The previous combined-figure builder was intentionally excluded because it contains superseded panels and intermediate output paths.

The original `06_single cell.R` CellChat draft contains a stale `nSMC` label in a plotting section. The corrected label appears later in that source file, but a complete final CellChat rendering script could not be verified from the available sources. The curated folder therefore includes the normalized CellChat sensitivity workflow and does not identify the stale draft as the final figure source.

## Start here

- `CODE_MAP.csv`: manuscript/panel and reviewer-comment mapping.
- Each section's `README.md`: categorized script index.
- `VALIDATION.md`: checks performed and their limits.
- `NOTICE.md`: source attribution and licensing note.
