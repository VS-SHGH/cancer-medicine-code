# Code package checks

- 37 files are indexed: 33 analysis/plot scripts and 4 configuration dependencies.
- Syntax check: 36 retained R scripts parsed successfully; the retained Python summary script passed Python AST parsing.
- Static path scan: no user-specific absolute paths remain in code.
- The package includes no patient datasets or serialized patient-level objects.
- Scientific analyses were not executed during curation. Required input workbooks, serialized objects, expression matrices and prior result tables must be supplied separately.
- Results that rely on external annotation databases may vary with database and package versions.
- Several main figure panels were finalized by manual assembly. See the Figure source notes in README.md.
